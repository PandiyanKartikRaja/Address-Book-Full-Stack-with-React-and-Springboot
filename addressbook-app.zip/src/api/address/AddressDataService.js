import axios from 'axios';
import { API_URL,JPA_API_URL } from '../../Constants'

class AddressDataService{

    retriveAllAddress(name){
        return axios.get(`${JPA_API_URL}/users/${name}/address`)
        //console.log('excuted service')

    }
    retriveAddress(name,id){
        return axios.get(`${JPA_API_URL}/users/${name}/address/${id}`)
        //console.log('excuted service')

    }

    deleteAddress(name, id){
        return axios.delete(`${JPA_API_URL}/users/${name}/address/${id}`)
        //console.log('excuted service')

    }
    updateAddress(name, id, addres){
        return axios.put(`${JPA_API_URL}/users/${name}/address/${id}`, addres);
        //console.log('excuted service')

    }
    createAddress(name, addres){
        return axios.post(`${JPA_API_URL}/users/${name}/address/`, addres);
        //console.log('excuted service')

    }

}

export default new AddressDataService()