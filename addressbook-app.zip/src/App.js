import React , { Component } from 'react';
import Addressbook from './Components/Addressbook/Addressbook';
//import logo from './logo.svg';
import './App.css';
import './bootstrap.css';

class App extends Component {
  render(){
  return (
    <div className="App">
      <Addressbook/>
    </div>
  );
}
}

export default App;
