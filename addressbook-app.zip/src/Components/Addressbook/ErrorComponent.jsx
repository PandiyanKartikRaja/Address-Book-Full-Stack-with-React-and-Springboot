import React  from 'react';

function ErrorComponent() {
    return <div>An Error Occurred. Invaild Page ! Contact Support:<a href>href=abcd@gmail.com</a></div>
}

export default ErrorComponent;