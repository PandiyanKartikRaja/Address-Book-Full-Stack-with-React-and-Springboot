import React , { Component } from 'react';
import AddressDataService from '../../api/address/AddressDataService.js'
import AuthenticationService from './AuthenticationService.js'

class ListAddressComponent extends Component{
    constructor(props){
        super(props)
        this.state = {
          address : [],
          message : null
        }

        this.createAddressClicked = this.createAddressClicked.bind(this)
        this.deleteAddressClicked = this.deleteAddressClicked.bind(this)
        this.updateAddressClicked = this.updateAddressClicked.bind(this)
        this.refreshAddress = this.refreshAddress.bind(this)

      }

      componentDidMount(){
       this.refreshAddress();

      }

      refreshAddress(){
        let username = AuthenticationService.getLoggedInUserName()
        AddressDataService.retriveAllAddress(username)
        .then(
            response => {
              console.log(response)
              this.setState({address : response.data});
            }
        )
      }

      deleteAddressClicked(id){
        let username = AuthenticationService.getLoggedInUserName()
        AddressDataService.deleteAddress(username, id)
        .then(
          response => {
            this.setState({message : `Delete of Address ${id} Success`});
            this.refreshAddress();
          }
        )

      }
      createAddressClicked(){
        this.props.history.push(`/address/-1`)
        
      }

      updateAddressClicked(id){
        this.props.history.push(`/address/${id}`)
        
      }
  
      render() {
        return (
            <div>
                <div className="Container">
                    <h1>Addresss Book</h1>
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                      <div className="column">
                          <button className="btn btn-success" onClick ={this.createAddressClicked}>Create</button>
                      </div>
                    <table className="table">
                      <thead>
                        <tr>
                          <th>FullName</th>
                          <th>House No.</th>
                          <th>Street</th>
                          <th>Contact</th>
                          <th>City</th>
                          <th>Zip</th>
                          <th>Update</th>
                          <th>Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                        {
                          this.state.address.map(
                              address =>
                                    <tr key={address.id}>
                                    <td>{address.fname}</td>
                                    <td>{address.apartment}</td>
                                    <td>{address.street}</td>
                                    <td>{address.contact}</td>
                                    <td>{address.city}</td>
                                    <td>{address.zip}</td>
                                    <td><button className="btn btn-success" onClick = { () => this.updateAddressClicked(address.id)}>Update</button></td>
                                    <td><button className="btn btn-warning" onClick = { () => this.deleteAddressClicked(address.id)}>Delete</button></td>
                                    </tr>
                          )
                        }         
                      </tbody>
                    </table>
                    </div>
            </div>
        )
      }
}
export default ListAddressComponent;
