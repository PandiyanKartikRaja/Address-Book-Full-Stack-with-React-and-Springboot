import React, {Component} from 'react';
import {Formik, Form, Field, ErrorMessage} from 'formik';
import AddressDataService from '../../api/address/AddressDataService.js'
import AuthenticationService from './AuthenticationService.js'

class AddressComponent extends Component{
    constructor(props){
        super(props)
        this.state = {
          id : this.props.match.params.id,
          fname: '',
          apartment: '',
          street: '',
          contact :'' ,
          city: '',
          zip : ''

        }

        this.onSubmit = this.onSubmit.bind(this)
        this.validate = this.validate.bind(this)
    }
    
    componentDidMount(){

        if(this.state.id===-1){
            return
        }

        let username = AuthenticationService.getLoggedInUserName()
        AddressDataService.retriveAddress(username, this.state.id)
        .then(response => this.setState({
            fname:response.data.fname,
            apartment:response.data.apartment,
            street:response.data.street,
            contact:response.data.contact,
            city:response.data.city,
            zip:response.data.zip,


        }))
    }

    validate(values){
        let errors ={}
        if(!values.fname){
            errors.fname="Enter A City"
        } else if(values.fname.length<4){
            errors.fname="Enter at least 4 Characters"
        }
        if(!values.apartment){
            errors.apartment="Enter Apartmen No."
        } else if(values.apartment.length<4){
            errors.apartment="Enter at least 4 Characters"
        }
        if(!values.street){
            errors.street="Enter A Street"
        } else if(values.street.length<4){
            errors.street="Enter at least 4 Characters"
        }

        if(!values.contact){
            errors.contact="Enter A Contact"
        }else if(values.contact.length<10){
            errors.city="Enter at least 10 Numbers"
        }

        if(!values.city){
            errors.city="Enter A City"
        }


        if(!values.zip){
            errors.zip="Enter A Valid Zip Code"
        }

        return errors;

    }


    onSubmit(values){

        if (this.state.id === -1) {
            let username = AuthenticationService.getLoggedInUserName()
            AddressDataService.createAddress(username,  {
                id: this.state.id,
                fname: values.fname,
                apartment: values.apartment,
                street: values.street,
                contact: values.contact,
                city: values.city,
                zip: values.zip

            }).then(() => this.props.history.push('/listaddress/'))
        } else {


            let username = AuthenticationService.getLoggedInUserName()
            AddressDataService.updateAddress(username, this.state.id, {
                id: this.state.id,
                fname: values.fname,
                apartment: values.apartment,
                street: values.street,
                contact: values.contact,
                city: values.city,
                zip: values.zip

            }).then(() => this.props.history.push('/listaddress/'))
        }

    }
    

    
    render(){
        let {fname,apartment,street,contact,city,zip } = this.state

        return (
            <div>
                <h1>Address</h1>
                <div className="container">
                    <Formik
                    
                    initialValues={{fname,apartment,street,contact,city,zip }}
                    onSubmit={this.onSubmit}
                    validate={this.validate}
                    enableReinitialize={true}
                    >
                        {
                            (props) => (
                                <Form>
                                    <ErrorMessage name="fname" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <ErrorMessage name="apartment" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <ErrorMessage name="street" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <ErrorMessage name="contact" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <ErrorMessage name="city" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <ErrorMessage name="zip" component ="div" className="alert alert-warning"></ErrorMessage>
                                    <fieldset className="form-group">
                                        <label>FullName</label>
                                        <Field className="form-control" type="text" name = "fname"></Field>
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>Apartment No.</label>
                                        <Field className="form-control" type="text" name = "apartment"></Field>
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>street</label>
                                        <Field className="form-control" type="text" name = "street"></Field>
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>Contact</label>
                                        <Field className="form-control" type ="number" name ="contact"></Field>
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>City</label>
                                        <Field className="form-control" type ="text" name ="city"></Field>
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>Zip</label>
                                        <Field className="form-control" type ="number" name ="zip"></Field>
                                    </fieldset>
                                    <button className="btn btn-success" type="submit">Save</button>
                                </Form>
                                    
                            )
                        }

                    </Formik>
                </div>
            </div>
        ) 
    }
}

export default AddressComponent;