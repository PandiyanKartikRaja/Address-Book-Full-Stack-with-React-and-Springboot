import React , {Component} from 'react';

export default class FirstComponent extends Component {
    render(){
    return (
      <div className="FirstComponent">
       Welcome To Address Book
      </div>
    );
  }
  }