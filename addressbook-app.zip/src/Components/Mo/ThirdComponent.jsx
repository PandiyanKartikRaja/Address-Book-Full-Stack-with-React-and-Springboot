import React , {Component} from 'react';
export default function ThirdComponent() {
    return (
      <div className="ThirdComponent">
       Create|Edit|Updte|Delete
      </div>
    );
  }