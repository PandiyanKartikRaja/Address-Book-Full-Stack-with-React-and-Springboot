insert into address(id, username, fname, apartment ,street, contact, city,  zip)
values(10001, 'spkarthik', 'Rahul', 'Qtr No. 40','3rd Street Umesh Nagar', 77898321, 'Delhi', 88245);

insert into address(id, username, fname, apartment,street, contact, city,  zip)
values(10002, 'spkarthik', 'suresh', 'Qtr No. 50','3rd Street raj Nagar', 77898324, 'Rajasthan', 88242);

insert into address(id, username, fname, apartment,street, contact, city,  zip)
values(10003, 'spkarthik', 'umesh', 'Qtr No. 45','3rd Street kailaash Nagar', 77898387, 'Kolkata', 88212);


